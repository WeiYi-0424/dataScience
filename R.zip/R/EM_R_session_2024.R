## TA Session 3: Introduction to R 
## Fall Semester 2024
## Adapted by Tabea Braun 
## This script builds on code from Jiajing Feng and 
## code from Matteo Courthoud (https://github.com/matteorg/intro_R_for_Econometrics/blob/main/IntroToR.R)


################################################################################
### Install R and R studio
################################################################################

# R: www.r-project.org
# RStudio: www.rstudio.com

## IMPORTANT ##
# Make sure you have the most recent version of R installed on your notebook
# Some packages won't be installed/loaded otherwise

################################################################################
### Some useful links to learn R
################################################################################

# Introduction to R for Economists: https://www.youtube.com/watch?v=kD1qq5tBrLg&list=PLcTBLulJV_AIuXCxr__V8XAzWZosMQIfW
# R for Econometrics: https://raw.githack.com/uo-ec607/lectures/master/08-regression/08-regression.html
# R for Econometrics II: https://hhsievertsen.github.io/applied_econ_with_r/
# Rstudio basics: https://github.com/matteorg/r_for_very_beginners/tree/main
# Tutorial from 3 years ago (polished): https://github.com/matteorg/intro_R_for_Econometrics/blob/main/IntroToR.R

################################################################################
### Overview
################################################################################

# 0. Set working directory, install packages and getting help
# 1. Basic R objects
# 2. Import data
# 3. Clean data
# 4. Summarize data
# 5. Data visualization
# 6. Regressions and tests
# 7. R markdown

# 0. Set working directory, install packages and getting help -------------

### Clear the working space
# i.e. everything in the Environment (top-right corner of RStudio) will disappear
rm(list=ls())


### Set working directory
# what I usually do: session--set working directory--choose directory (you should choose the folder where you downloaded the R folder from OLAT)
setwd("C:/Users/tabea/Documents/PhD - Teaching/Empirical Methods/R")
# Put your own!!
getwd()

##' Create subfolder within main directory
dir.create("Figures&Tables")

## Check what's inside folder "data"
list.files("./data")

### Install packages
# Install
install.packages("foreign")
# Load! (different from stata, need to load before use it)
library(foreign)

# Further packages that need to be installed for this RScript
install.packages("foreign")
install.packages("readr")
install.packages("readxl")
install.packages("dplyr")
install.packages("Hmisc")
install.packages("fastDummies")
install.packages("tidyr")
install.packages("vtable")
install.packages("stargazer")
install.packages("wooldridge")
install.packages("gapminder")
install.packages("ggplot2")
install.packages("gganimate")
install.packages("gifski")
install.packages("av")
install.packages("sandwich")
install.packages("lmtest")
install.packages("fixest")
install.packages("broom")
install.packages("modelsummary")
install.packages("AER")
install.packages("car")


### Getting help
help("cbind") # Get help for basic functions
?cbind  # Same as help()
?foreign::read.dta   # Certain function in a package
?`:`  # Help for symbol
# New: ask ChatGPT: "What does "read.dta" do in R?"


# 1. Basic R objects: values, vectors, matrices, data frames --------------

### Data types
typeof(3) # mostly numbers are stored as double
typeof(3.5)
typeof('hello') # strings are stored as character
typeof(TRUE) # logical
3 > 5
typeof(3 > 5)

### Assign a value
a <- 1  # shortcut: "option" + "-" for mac, "alt" + "-" for windows
typeof(a)

### Vector
# Create a vector
x <- c(1, 2, 3, 4, 5)
y <- c(4: 8)

# Show certain elements of a vector
x[2]  # By index: the index starts from 1 in R
y[2:4]
y[y > 5]  # By certain condition

### Matrices
# Create a matrix
z <- cbind(x, y)
z
class(z)
# Show certain elements
z[3, 2]   # Index: row 3, column 2
z[x > 3] # By certain condition

### Data frame
# Change matrix to data frame
w <- as.data.frame(z)
class(w)
dim(w)
# Create a new variable in a data frame
w$a <- c(6:10) # "$" Indicates which variable in which dataset
# Show certain element of certain variable
w[2, ] # Show second row
w[ , 3] # Show the third column
w$y[3] # Show third element of variable y

# Remove an object
rm(x)

# Clear working space
rm(list=ls())


# 2. Import data ----------------------------------------------------------

### Getting data from internet
# Store the url as an object
url <- "https://www.stats.govt.nz/assets/Uploads/Annual-enterprise-survey/Annual-enterprise-survey-2017-financial-year-provisional/Download-data/annual-enterprise-survey-2017-financial-year-provisional-csv.csv"
# Download the file. Important parameters: destination file
download.file(url, destfile = "data/asset.csv") # Then can check data is in the directory folder, can also specify location to store at certain folder
list.files("data")

### Read data
# Data come in several formats, and each usually requires a different function
# csv files
library(readr)
wagedata <- read_csv("data/sampleUScens2015.csv", col_names = TRUE)

# excel
library(readxl)
berkeleyData <- read_xls("data/berkeley.xls" )

# dta
library(foreign) # if it doesn't work, try read_dta from "haven" package
mrozData <- read.dta("data/mroz.dta" )

### View dataset
# Get to know dataset
dim(wagedata)  # Show dimension of dataset
colnames(wagedata)  # Show variable names
str(wagedata)  # Show dataset structure
# View dataset
head(wagedata) # Show what the dataset looks like from the top
head(wagedata, n = 10) # Specify number of obs to be shown
View(wagedata) # Open the dataset, same as click on the dataset
View(wagedata[wagedata$female==1, ]) # Only view certain rows with some condition
View(wagedata[,2:4]) # Only view certain columns
View(dplyr::select(wagedata, incwage:educ)) # Only show certain variables, need the select function from dplyr package
View(dplyr::select(wagedata,c('age','educ'))) # Select vars to be shown

### Remove dataset
rm(assetData)


# 3. Clean data -----------------------------------------------------------

library(dplyr)
### Rename variable
View(mrozData)
mrozData <- rename(mrozData, husband_age = husage, husband_education = huseduc, husband_wage = huswage)
# Two conventions: either husband_education, or husbandEducation

## Note: in R, always remember to say where you want R to put the altered object after any command
# Just run "rename(mrozData, husband_hours = hushrs)" won't do anything to the original dataset
rename(mrozData, husband_hours = hushrs) # Changed here
View(mrozData) # But not in original dataset

### Label a variable
library(Hmisc)
label(mrozData$hushrs) = "Working hours per year for husbands"
View(mrozData)

### Sort data
mroz_sort <- arrange(mrozData, educ)
mroz_sort <- arrange(mrozData, desc(educ))

### Create new variables
# Option 1 
mrozData = mutate(mrozData, log_hours=log(hours), hours_10 = hours/10)
# Option 2
mrozData$log_wage = log(mrozData$wage)

### Create a categorical variable based on certain condition
# Option 1
mrozData <-  mutate(mrozData, high_edu1 = factor((educ > 10), labels = c("low", "high")))   
# Check what factor function does: factor(mrozData$educ>10)
View(select(mrozData, c('educ','high_edu')))
# Option 2 (a bit slower)
mrozData$high_edu2[mrozData$educ <= 10] = "low"
mrozData$high_edu2[mrozData$educ > 10] = "high"
View(select(mrozData, c('educ','high_edu1', 'high_edu2')))

### Transform binary categorical into numeric dummy variable
mrozData$high_edu3 = as.numeric(mrozData$high_edu1=="high")
View(select(mrozData, c('educ','high_edu1', 'high_edu3')))

### Create dummies from categorical variable
library(fastDummies)
mrozData_dummy <- dummy_cols(mrozData, select_columns = "kidslt6")

### Drop variables from certain dataset
mrozData <- within(mrozData, rm("high_edu2","high_edu3"))
mrozData$high_edu1 = NULL

### Reorder variables
mrozData_relo <- relocate(mrozData, wage, educ, age)

### Merge datasets
# First just create two datasets for illustration, you can ignore this step
first_df <- tibble(
  country = c('Afghanistan', 'Belgium', 'China', 'Denmark'),
  population = c(333, 11, 1382, 57)
)
second_df <- tibble(
  country = c('Afghanistan', 'Belgium', 'Denmark', 'Germany'),
  gdp = c(35, 422, 211, 3232)
)
# The actual merge
left_join(first_df, second_df, by = "country")  # merge based on obs from first_df
right_join(first_df, second_df, by = "country") # merge based on obs from second_df
inner_join(first_df, second_df, by = "country") # merge based on common obs
full_join(first_df, second_df, by = "country") # merge based on obs from both first_df and second_df

### Create subset of data
## In R, can work with different data frames at the same time, not like stata
# Select some variables（columns)
sub1 <- subset(mrozData, select = age:wage)
sub2 <- subset(mrozData, select = c("hours","age","wage","husband_wage"))
# Select certain subsample(rows) based on certain condition
sub3 <- filter(mrozData, educ==12) # only obs with exactly 12 years of education
sub4 <- subset(mrozData, educ==12) # equivalent
# Of course can combine both and set more conditions
sub5 <- subset(mrozData, kidslt6==0 & educ>12, select = c("hours","age","wage","husband_wage", "educ"))

### Deal with missing values
# First create a small dataset with missing valus (you can ignore this step)
missing <- full_join(first_df, second_df, by = "country")
# Count number of missing values in certain variable
sum(is.na(missing$gdp)) # gives you 1 missing
is.na(missing$gdp) # TRUE if it's missing
# Create a new variable from existing variable if that var is not missing
missing$high_gdp <- NA # Initialize the variable with NA
missing$high_gdp[missing$gdp <= 300 & is.na(missing$gdp) == FALSE] = "low"
missing$high_gdp[missing$gdp > 300 & is.na(missing$gdp) == FALSE] = "high"
# Important remarks:
   # -You can use == (exactly equal), >, <, <=, >=, or != (not equal)
   # -While "&" means "and", "|" means "or"
   # -You cannot say missing$gdp!=NA to say "if gdp is not missing"
   # -You need to use is.na(variable_name)==TRUE/FALSE, which reads: [if variable is (TRUE) or is not (FALSE) missing (na)]

# Clean
rm(sub1, sub2, sub3, sub4, sub5)
rm(mroz_sort, mrozData_dummy, mrozData_relo)
rm(missing, first_df, second_df)


# 4. Summarize data -------------------------------------------------------

# Let's first create a folder for figures and tables
if(!file.exists("Figures&Tables")){
  dir.create("Figures&Tables")
}

### Summary of the whole dataset
summary(wagedata) # Brief summary of all variables

## Summary for a subset of dataset 
# Can use pipe operator %>%: "then" operator, can combine several steps in one command, shortcut: command+shift+m for mac
# 1. Create a var which is log of wages; 
# 2. Create a subset of data which only keeps var age, incwage and log_wage, and only keep observations for age >25; 
# 3. Summarize these three vars in the sub dataset--use %>% to do it in one step
wagedata %>% mutate(log_wage=log(incwage)) %>% subset(age > 25, select = c("age", "incwage", "log_wage")) %>% summary

### Basic summary statistics for one variable
mean(wagedata$incwage)
sd(wagedata$incwage)
summary(wagedata$incwage)
summarise(wagedata, mean_wage = mean(incwage, na.rm = TRUE), sd_wage = sd(incwage), median_wage = median(incwage), min_edu = min(educ))  #na.rm = TRUE means: calculate the mean ignoring any missing(remove the missings)
# Put certain summary statistics for certain vars into a table called sum1
sum1 <- summarise(wagedata, mean_wage = mean(incwage, na.rm = TRUE), sd_wage = sd(incwage), median_wage = median(incwage), min_edu = min(educ, na.rm = TRUE))

### Summary frequency
table(wagedata$firmsector) # Summary of frequency of categorical variable
mytable <- table(wagedata$firmsector, wagedata$degfield) # Summary of frequency by two categorical variables
mytable
options("scipen" = 10) # avoids that integers are printed as exponential
prop.table(mytable)
margin.table(prop.table(mytable), 1) # sector percentages, sum over degree field
margin.table(prop.table(mytable), 2) # degree field frequencies, sum over sectors

### Summarize by group
# Use group_by from dplyr, group by number of kids <6 years
group <- group_by(wagedata, firmsector)  # This doesn't change dataset itself, but changes how the dataset is perceived: group by kidslt6
summarise(group, mean_wage = mean(incwage), sd_wage = sd(incwage), max_wage = max(incwage))

# Or use vtable to get nicer tables
install.packages("vtable")
library(vtable)
st(wagedata) # Summarize all variables
# Problem: not all categorical variables are displayed since st() requires factors as input
wagedata$firmsector <- as.factor(wagedata$firmsector)
wagedata$occupation <- as.factor(wagedata$occupation)
wagedata$degfield <- as.factor(wagedata$degfield)
st(wagedata) # now all variables are displayed in the table

st(wagedata, group='occupation') # Summarize all variables by occupation

# Create a subset with certain vars
sub5 <- subset(wagedata, select = c("age","incwage","female", "childrenly", "educ", "firmsector"))
st(sub5, group='firmsector') # Summarize selected variable by firmsector (can also set certain condition)
st(sub5, group='firmsector', file='Figures&Tables/sum_group.html') # Store it as html file


### Use stargazer for summary table
library(stargazer)
wagedata <- data.frame(wagedata) # stargazer requires dataframes as input  
stargazer(wagedata, type="text", summary = TRUE) # As text
subset <- subset(wagedata, female==1, select = c(age, incwage, educ))
stargazer(subset, type = "html", out = "./Figures&Tables/sum_wagedata.html") # summary selected variables and export as html


# 5. Data visualization ---------------------------------------------------
# The wagedata dataset contains many observations and running the following code with all observations take time
# For illustration we take a random sample of 50,000 observations 
set.seed(999) # For replicability --> 'set.seed' before simulating samples 
wagedata <- sample_n(wagedata, 50000) # take a random sample of rows


### Basic plots
# Basic histogram
hist(wagedata$age)
# Scatter plot
with(wagedata, plot(educ, incwage)) # Option 1
plot(wagedata$educ, wagedata$incwage) # Option2
# Add title
plot(wagedata$educ, wagedata$incwage, main = "Years of Education and Wages") 
# Label x, y axis
plot(wagedata$educ, wagedata$incwage, main = "Years of Education and Wages", xlab ="Years of Education", ylab = "Wage Income") 
# Specify lower and upper limit of axes
plot(wagedata$educ, wagedata$incwage, main = "Years of Education and Wages", xlab ="Years of Education", ylab = "Wage Income", xlim = c(1,25)) 
# Change color of a subset of your datapoints
plot(wagedata$educ, wagedata$incwage)  # the original plot
with(subset(wagedata, educ > 12), points(educ, incwage, col = "blue")) # change obs with more than 12 years of educ to blue
with(subset(wagedata, educ <= 12), points(educ, incwage, col = "red")) # change obs with less than 12 years of educ to red
legend("topright", pch = 1, col = c("blue", "red"), legend = c("More than Highschool", "Highschool or Less"), pt.cex=0.7, cex=0.7)
# Note: pch: type of symbols; col: color;cex: size of the box;pt.cex:size of symbols in legend;--can refer to cheatsheet, see "R_reference_card"
# Add a line
abline(a=0,b=10000) # line y = a + bx
abline(h=60000, col = "grey") # Horizontal line at 30,000 with grey blue
abline(v=12.5, col = "red") # Vertical line at 12.5 with color red


### Nicer plots with ggplot2
# ggplot2 reference: https://ggplot2.tidyverse.org/reference/
library(wooldridge)
library(ggplot2)

## Plots for one variable
# Histogram
ggplot(wagedata) +
  geom_histogram(aes(x = age), bins = 30)
# Bar graph
ggplot(wagedata) +
  geom_bar(aes(x = firmsector))
# Density plot
ggplot(wagedata) +
  geom_density(aes(x = incwage))
# Density plot by continent
ggplot(wagedata) +   
  geom_density(aes(x = incwage, color = degfield))

## Scatter plot for two variables
# Generate an empty graph with only axis
ggplot(wagedata, aes(x = educ, y = incwage))
# Add points
ggplot(wagedata) + geom_point(aes(x = educ, y = incwage))
# Change the point color, size and transparency of all points--write outside aes()
ggplot(wagedata) + geom_point(aes(x = educ, y = incwage), color = 'blue') # Color
ggplot(wagedata) + geom_point(aes(x = educ, y = incwage), size = 0.5) # Size
ggplot(wagedata) + geom_point(aes(x = educ, y = incwage), alpha = 0.5) # Alpha changes transparency
# Change the point color, size and transparency by variable-write inside aes()
ggplot(wagedata) + geom_point(aes(x = educ, y = incwage, color = degfield)) # Color
ggplot(wagedata) + geom_point(aes(x = educ, y = incwage, color = educ > 12)) # Change color by specified condition
ggplot(wagedata) + geom_point(aes(x = age, y = educ, size = incwage)) # Size
# not a great choice for our dataset
ggplot(wagedata) + geom_point(aes(x = age, y = educ, alpha = incwage)) # Transparency
# not a great choice either

# Adding more to the plot
g <- ggplot(wagedata) + geom_point(aes(x = educ, y = incwage, color = degfield))
g
# Add labels, title and caption
g1 <- g + 
  labs(x =  'Years of Education', 
        y = 'Wage Income',
        color = 'Degree Field',
        title = 'Relationship between Years of Education and Wage Income',
        caption = 'dataset: wagedata')
g1
# Change scale of axis
g1 + 
  scale_y_continuous(breaks = seq(0,600000,50000))
  
# Add a smooth fit
g1 +
  geom_smooth(aes(x = educ, y = incwage), color = 'red')
  
# Add a linear fit, without confidence interval
g1 +
  geom_smooth(aes(x = educ, y = incwage), method = lm, se = FALSE, color = 'red')

# Plot multiple plots
ggplot(data = wagedata) +
  geom_point(aes(x = educ, y = incwage)) +
  facet_wrap(~degfield, nrow = 2)

# Can also change themes
g1
g1 +
  theme_bw()
g1 + 
  theme_classic()
g1 + 
  theme_dark()

# Save the plot
ggsave('Figures&Tables/figure1.png',plot = g1, width = 8, height = 6, dpi = 300)

# Last fancy thing: animation!
# Load a new dataset: gapminder
library(gapminder)
gapminder <- gapminder

install.packages("gganimate")
library(gganimate)
install.packages("gifski")
install.packages("av")
library(gifski)
library(av)

# First we plot the graph 
# Adding more to the plot
a <- ggplot(gapminder) + geom_point(aes(x = gdpPercap, y = lifeExp, color = continent))
a
# Add labels, title and caption
a1 <- a + 
  labs(x =  'GDP per capita', 
       y = 'life expectancy',
       color = 'Continent',
       title = 'Relationship between life expectancy and GDP per capita',
       caption = 'dataset: gapminder')

# Now the animation
a1 +
  # Here comes the gganimate specific bits
  labs(title = 'Year: {frame_time}', x = 'GDP per capita', y = 'life expectancy') +
  transition_time(year) +
  ease_aes('linear')


# 6. Regressions and tests ------------------------------------------------
library(wooldridge)
library(gapminder)
gapminder <- gapminder
View(gapminder)

### Simple OLS with only one regressor
ols1 <- lm(lifeExp ~ gdpPercap, data = gapminder)  # By default, including a constant
summary(ols1)
library(stargazer)
stargazer(ols1, type = 'text')
# Recover coefficients by hand:
# Vector notation
y = gapminder$lifeExp
x = gapminder$gdpPercap # define x and y
# Plug in the formula
beta_1 = cov(x,y)/var(x)
beta_0 = mean(y)-beta_1*mean(x)
beta_0 
round(beta_1, digits = 3) # round it to the 3rd decimal
# Matrix notation
X = as.matrix(cbind(1,gapminder$gdpPercap))
head(X)
dim(X)
Y = as.matrix(gapminder$lifeExp)
head(Y)
dim(Y)
beta = solve(t(X)%*%X)%*%t(X)%*%Y  # solve(A) gives the inverse of A where A is a square matrix  
beta
round(beta, digits = 3)

### Add more controls
ols2 <- lm(lifeExp ~ gdpPercap + pop, data = gapminder)
stargazer(ols2, type = 'text')
# Can also add transformed controls
ols3 <- lm(lifeExp ~ log(pop) + gdpPercap + I(gdpPercap^2), data = gapminder) # I(gdpPercap^2) gives squared gdpPercap term
stargazer(ols3, type = 'text')
# Interaction term
ols4 <- lm(lifeExp ~ gdpPercap + pop + gdpPercap:pop, data = gapminder) # gdpPercap:pop gives interaction term
stargazer(ols4, type = 'text')
ols5 <- lm(lifeExp ~ gdpPercap*pop, data = gapminder) # equivalent to ols4
stargazer(ols5, type = 'text')

### Display two regressions together and export
stargazer(ols1, ols2, title="Results", align=TRUE, type="text")
# Can add lines
stargazer(ols1, ols2, title="Results", align=TRUE, type="text", add.lines = list(c("Controls", "No", "Yes")))  
# Export
stargazer(ols1, ols2, title="Results", align=TRUE, type="text", add.lines = list(c("Controls", "No", "Yes")), out="Figures&Tables/ols.html") 

# Get certain coefficient and store it
summary(ols2)
coef(ols2)[2] # coef for beta_2
summary(ols2)$coefficients
coeff <- summary(ols2)$coefficients[2,1]
std <- summary(ols2)$coefficients[2,2]
p <- summary(ols2)$coefficients[2,4]
print(paste("Coefficient is",coeff,
            "standard error is", std, 
            "p value is", p)) # could also round them to look better


# Store and check the residuals 
resid1 <- resid(ols2)
head(resid1)
mean(resid1)
round(mean(resid1), digits = 3)
plot(fitted(ols2), resid1) # plot residuals against fitted values to check homoskedasticity
abline(h = 0)
plot(density(resid1)) # check if it's roughly bell-shaped

### Robust standard errors
library(sandwich)
library(lmtest)
stargazer(coeftest(ols2,vcovHC),type="text") # Heteroskedasticity

### Clustered standard errors
stargazer(coeftest(ols2,vcovCL, cluster=gapminder$country),type="text") # Cluster at country level

### Add fixed effects
library(fixest)
fe1 <- feols(lifeExp ~ gdpPercap + pop | continent, data = gapminder) # continent FE
summary(fe1)
# This package is also easy for robust and cluster standard errors
fe2 <- feols(lifeExp ~ gdpPercap + pop | continent, se = 'hetero', data = gapminder) # robust SE
summary(fe2)
fe3 <- feols(lifeExp ~ gdpPercap + pop | continent, cluster = c('country') , data = gapminder) # cluster SE at country level
summary(fe3)
# Another way to look at the results
library(broom)
fe2 <- tidy(fe1)
# Other ways to run fixed effects: use plm or add factor() to lm

### Create regression table (unfortunately feols doesn't work with stargazer)
library(modelsummary)
models <- list('OLS' = ols2, 'FE' = fe1)  #put the models into a list first
modelsummary(models)
# Add labels, stars, omit some stats
modelsummary(models, coef_map = c('gdpPercap' = 'GDP per capita', 'pop' = 'population'), 
             gof_omit = "AIC|BIC|DF|Deviance|IC|Log|Adj|Pseudo|Within|se_type", stars = c('*'  = 0.1, '**' = 0.05, '***' = 0.01))

### Export 
modelsummary(models, coef_map = c('gdpPercap' = 'GDP per capita', 'pop' = 'population'), 
             gof_omit = "AIC|BIC|DF|Deviance|IC|Log|Adj|Pseudo|Within|se_type", stars = c('*'  = 0.1, '**' = 0.05, '***' = 0.01), output = 'Figures&Tables/results.tex')



### Instrumental variable (IV) regression
ivdata <-  wooldridge::card # need another dataset with instrument
# OLS result
ols <-  lm(wage ~ educ + black + fatheduc + exper + IQ + south 
            + married + momdad14, data=ivdata)
# Use nearc2 (which is a dummy indicating whether the house is close to a 4-year college) as instrument for education
library(AER)
iv1 = ivreg(wage ~ educ + black + fatheduc + exper + IQ + south 
              + married + momdad14 | nearc4 + black + fatheduc + exper + IQ + south 
              + married + momdad14, data = ivdata)
stargazer(ols, iv1, type = 'text')
firststage = lm(educ ~ nearc4 + black + fatheduc + exper + IQ + south 
                + married + momdad14, data=ivdata)
stargazer(firststage, type = 'text')

# Or use feols again
iv2 = feols(wage ~ black + fatheduc + exper + IQ + south 
            + married + momdad14 | educ ~ nearc4, data = ivdata)
summary(iv2)
summary(iv2, stage = 1)



### Some hypotheses testing
# Simple t tests
# Want to test whether mean wage is different from 0
mean(ivdata$wage) # Have a look at mean wage
t.test(ivdata$wage) # t test: if the mean equals 0
t.test(ivdata$wage - 577) # Test if the mean is 577
# Compare father education with mother education
mean(ivdata$fatheduc, na.rm = TRUE)
mean(ivdata$motheduc, na.rm = TRUE)
t.test(ivdata$fatheduc - ivdata$motheduc) # Test if the mean of father education is same as mother education
t.test(ivdata$fatheduc - ivdata$motheduc, alternative = c("less")) # test if father's education is higher than mother's education


# F tests
library(car)
linearHypothesis(ols,c("black = 0", "exper = 0"), type = c("F"))   # Test if the coefficient on black and the coefficient on exper are jointly 0, from the regression in line 566


##########################################
# Before we finish: how to open Markdown #
##########################################
# Go to 'file' ---> 'New File' ---> 'R Markdown'
# You may get a message asking to install 1 or more packages. Do it.
# Then you have to select the 'type' of document you want to produce
# Select 'document' (you may notice you can also prepare presentations)
# Type the title of the document (example: "Problem Set 1")
# Type the author(s)
# Select output format (I would say 'pdf') then press 'ok'
# A new document will open. Save it in subfolder within your working directory
# Then you can start using the document. You can look at the uploaded template for more.



